// React entry file placeholder. Actual content injected in the main build process.
import ReactDOM from "react-dom";
import Home from "./Home";
ReactDOM.render(<Home />, document.getElementById("root"));
